/*
 * @Author: chenxy
 * @Date: 2021-01-03 15:40:09
 * @LastEditTime: 2021-01-06 00:08:37
 * @LastEditors: Please set LastEditors
 * @Description: 路由
 * @FilePath: \novel\src\router\index.js
 */
import Vue from 'vue'
import Router from 'vue-router'
import home from '@/view/home'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: home
    }
  ]
})
