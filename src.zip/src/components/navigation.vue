<!--
 * @Author: chenxy
 * @Date: 2021-01-05 00:08:42
 * @LastEditTime: 2021-01-05 16:40:59
 * @LastEditors: Please set LastEditors
 * @Description: 导航
 * @FilePath: \novel\src\components\navigation.vue
-->
<template>
  <div>
    <el-menu default-active="1" class="el-menu-demo" mode="horizontal" @select="handleSelect"
      background-color="#669999" text-color="#fff" active-text-color="#ffd04b">
      <el-menu-item index="1">首页  </el-menu-item>
      <el-menu-item index="2">书单</el-menu-item>
      <el-menu-item index="3">分类</el-menu-item>
      <el-menu-item index="4">排行榜</el-menu-item>
      <el-menu-item index="5">客户端</el-menu-item>
    </el-menu>
  </div>
</template>
<script>
export default {
  name: 'navigation',
  data() {
    return {
    }
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    }
  }
}
</script>
<style scoped>
.el-menu {
  padding-left: 20%;
}
.el-menu-item {
  padding: 0 60px;
}
</style>